export interface IInput{
  nameInput: string;
  typeInput: string;
  placeholder: string;
  icon: string;
  eye?: string;
  showPassword?: () => void;
}