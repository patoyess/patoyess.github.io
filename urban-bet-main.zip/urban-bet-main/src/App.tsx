import PagLogin from "./pages/PagLogin/pagLogin";
import { AppContainer } from "./styles/global";

function App() {
  return (
    <AppContainer>
      <PagLogin />
    </AppContainer>
  );
};

export default App;
